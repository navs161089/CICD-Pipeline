import requests
def call_myweb(event=None, context=None):
    r=requests.get("http://naveen161089.blogspot.com")
    if r.status_code == 200:
        return "The website responds fine"

